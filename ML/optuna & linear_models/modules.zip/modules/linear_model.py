import numpy as np
from scipy.special import expit
import time


class LinearModel:
    def __init__(
        self,
        loss_function,
        batch_size=100,
        step_alpha=1,
        step_beta=0, 
        tolerance=1e-5,
        max_iter=1000,
        random_seed=153,
        **kwargs
    ):
        """
        Parameters
        ----------
        loss_function : BaseLoss inherited instance
            Loss function to use
        batch_size : int
        step_alpha : float
        step_beta : float
            step_alpha and step_beta define the learning rate behaviour
        tolerance : float
            Tolerace for stop criterio.
        max_iter : int
            Max amount of epoches in method.
        """
        self.loss_function = loss_function
        self.batch_size = batch_size
        self.step_alpha = step_alpha
        self.step_beta = step_beta
        self.tolerance = tolerance
        self.max_iter = max_iter
        self.random_seed = random_seed
        self.w = None

    def fit(self, X, y, w_0=None, trace=False, X_val=None, y_val=None):
        """

        Parameters
        ----------
        X : numpy.ndarray or scipy.sparse.csr_matrix
            2d matrix, training set.
        y : numpy.ndarray
            1d vector, target values.
        w_0 : numpy.ndarray
            1d vector in binary classification.
            2d matrix in multiclass classification.
            Initial approximation for SGD method.
        trace : bool
            If True need to calculate metrics on each iteration.
        X_val : numpy.ndarray or scipy.sparse.csr_matrix
            2d matrix, validation set.
        y_val: numpy.ndarray
            1d vector, target values for validation set.

        Returns
        -------
        : dict
            Keys are 'time', 'func', 'func_val'.
            Each key correspond to list of metric values after each training epoch.
        """
        X = np.concatenate([np.ones(X.shape[0]).reshape(-1, 1), X], axis=1)
        X_val = X_val if X_val is not None else X
        y_val = y_val if y_val is not None else y
        w_0 = w_0 if w_0 is not None else np.random.normal(size=X.shape[1])
        history = {'time': [], 'func': [], 'func_val': []}
        prev_loss = float('inf')
        for k in range(self.max_iter):
            perm_idxs = np.random.default_rng().permutation(X.shape[0])
            t = time.time()
            for batch in range(0, X.shape[0], self.batch_size): # it can be sped up by using njit actually
                idxs = perm_idxs[batch : batch + self.batch_size]
                lr   = self.step_alpha / (k+1)**self.step_beta
                w_0 -= lr * self.loss_function.grad(X[idxs], y[idxs], w_0)
            loss = self.loss_function.func(X, y, w_0)
            if trace:
                history['time'].append(time.time() - t)
                history['func'].append(loss)
                history['func_val'].append(self.loss_function.func(X_val, y_val, w_0))
            if np.abs(prev_loss - loss) < self.tolerance:
                self.w = w_0
                break
            prev_loss = loss
        self.w = w_0
        return history
          

    def predict(self, X, threshold=0):
        """

        Parameters
        ----------
        X : numpy.ndarray or scipy.sparse.csr_matrix
            2d matrix, test set.
        threshold : float
            Chosen target binarization threshold.

        Returns
        -------
        : numpy.ndarray
            answers on a test set
        """
        X = np.concatenate([np.ones(X.shape[0]).reshape(-1, 1), X], axis=1)
        if self.w is None:
            raise Exception('Model is not fitted')
        return np.sign(X@self.w-threshold)
    
    def predict_proba(self, X):
        """
        Parameters
        ----------
        X : numpy.ndarray or scipy.sparse.csr_matrix
            2d matrix, test set.

        Returns
        -------
        : numpy.ndarray
            answers on a test set
        """
        X = np.concatenate([np.ones(X.shape[0]).reshape(-1, 1), X], axis=1)
        if self.w is None:
            raise Exception('Model is not fitted')
        return expit(X@self.w)

    def get_weights(self):
        """
        Get model weights

        Returns
        -------
        : numpy.ndarray
            1d vector in binary classification.
            2d matrix in multiclass classification.
            Initial approximation for SGD method.
        """
        if self.w is None:
            raise Exception('Model is not fitted')
        return self.w

    def get_objective(self, X, y):
        """
        Get objective.

        Parameters
        ----------
        X : numpy.ndarray or scipy.sparse.csr_matrix
            2d matrix.
        y : numpy.ndarray
            1d vector, target values for X.

        Returns
        -------
        : float
        """
        if self.w is None:
            raise Exception('Model is not fitted')
        return self.loss_function.func(X, y, self.w)