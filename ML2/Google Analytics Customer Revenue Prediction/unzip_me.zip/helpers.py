import os
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from tqdm import tqdm
from datetime import datetime, timedelta
from imblearn.over_sampling import ADASYN
from imblearn.under_sampling import TomekLinks
from imblearn.under_sampling import ClusterCentroids
from sklearn.cluster import MiniBatchKMeans
from sklearn.model_selection import train_test_split
import lightgbm as lgb
import pickle
from IPython.display import Image

# ===========================================================================
# 1. Preprocessing
# ===========================================================================

def get_df_info(df, *args, **kwargs):
  '''
  Выводит инфу о колонках датафрейма в виде датафрейма
  
  df: 
    исходный датафрейм
  
  # инфа:
  ex1:
    рандомный элемент 
  ex2:
    рандомный элемент отличный от ex1
  vc_max:
    мода и ее частота ее встречаемости
  trash_score:
    max[#nans+#zeros+#empty_str, vcmax.частота*(vcmax.частота>thr)]
  unique, nan, zero, empty_str:
    количество различных/нанов/0/пустых строк

  returns: pd.DataFrame с инфой
  '''
  params = {'thr' : 0.5,}
  params.update(kwargs)

  newdf = pd.DataFrame(index=df.columns)
  newdf['dtype']     = df.apply(lambda col: col.dtype.name)
  newdf['ex1']       = df.apply(lambda col: col.sample(1).iloc[0])
  newdf['ex2']       = df.apply(lambda col: col[col!=newdf['ex1'][col.name]].sample(1).iloc[0] if col.nunique()>1 else None)
  newdf['vc_max']    = df.apply(lambda col: (mode:=col.value_counts(sort=False).idxmax() if col.nunique()>=1 else None, (col==mode).mean().round(3)), result_type='reduce')
  newdf['unique']    = df.apply(lambda col: col.nunique(dropna=False))
  newdf['nan']       = df.apply(lambda col: x if (x:=col.isna().mean()) else -1)
  newdf['zero']      = df.apply(lambda col: x if (x:=(col==0).mean()  ) else -1)
  newdf['empty_str'] = df.apply(lambda col: x if (x:=(col=='').mean() ) else -1)

  newdf['temp1'] = newdf['vc_max'].apply(lambda x: x[1] if x[1]>params['thr'] else 0)
  newdf['temp2'] = newdf['nan'].replace(-1,0)+newdf['zero'].replace(-1,0)+newdf['empty_str'].replace(-1,0)
  newdf['trash_score'] = newdf[['temp1','temp2']].max(axis=1)
  newdf.loc[df.nunique()[df.nunique()==0].index, 'trash_score'] = 1
  newdf.drop(columns=['temp1', 'temp2'], inplace=True)

  # round by 3 digits and add special symbols:
  newdf = newdf.round(3)
  newdf['nan']       = newdf['nan'].apply(lambda x: f'n: {x}'  if x!=-1 else -1)
  newdf['zero']      = newdf['zero'].apply(lambda x: f'z: {x}' if x!=-1 else -1)
  newdf['empty_str'] = newdf['empty_str'].apply(lambda x: f'e: {x}' if x!=-1 else -1)

  if params.get('display', False):
    from IPython.display import display
    display(newdf)
    return None
  return newdf

def proper_types(df):
  df["date"] = pd.to_datetime(df["date"], format="%Y%m%d")
  df['totals_hits'] = df['totals_hits'].astype(float)
  df['totals_pageviews'] = df['totals_pageviews'].astype(float)
  df['totals_newVisits'] = df['totals_newVisits'].astype(float)
  df['device_isMobile'] = df['device_isMobile'].astype(bool)
  df['visitNumber'] = df['visitNumber'].fillna(0).astype(float)
  df['trafficSource_isTrueDirect'] = df['trafficSource_isTrueDirect'].astype(bool)
  df['totals_bounces'] = df.totals_bounces.astype(float)
  return df.sort_values('date')

cat_features = [
  'most_freq_device_isMobile',
  'most_freq_device_deviceCategory',
  'most_freq_device_operatingSystem',
  'most_freq_networkDomain',
  'most_freq_channelGrouping',
  'most_freq_trafficSource_medium',
  'most_freq_trafficSource_source',
  'most_freq_trafficSource_keyword',
  ]
zero_query = '\
  most_freq_device_deviceCategory=="tablet" or \
  most_freq_channelGrouping=="Affiliates" or \
  most_freq_trafficSource_medium=="affiliate" or \
  most_freq_trafficSource_source in ["youtube.com", "Partners"] or \
  most_freq_networkDomain=="unknown.unknown"\
  '
not_features = ['target', 'fullVisitorId', 'clf_target']

def features_pipeline(df_full, is_train=True, gap=10):
  '''
  генерит фичи на данных до gap, таргет генерится после gap
  '''
  delta = timedelta((31+gap)*is_train)
  mask_train  = df_full.date <= df_full.date.max() - delta
  if is_train:
    mask_target = df_full.date >= df_full.date.max() - timedelta(31)
    users_train = df_full[mask_train].fullVisitorId.unique()
    target = df_full[df_full.fullVisitorId.isin(users_train)].groupby("fullVisitorId").apply(
      lambda x: np.log1p(x.loc[mask_target].totals_transactionRevenue.sum()), 
      include_groups=False
      )
  # is_returned = target.index.isin(df_full.loc[mask_target, 'fullVisitorId'])

  f_most_freq = lambda x: x.dropna().value_counts().index[0] if len(x.dropna()) else None
  f_uninque = lambda x: x.dropna().nunique()

  date_min = df_full.date.min()
  date_max = df_full.date.max() - delta
  df = df_full[mask_train].groupby("fullVisitorId").agg(
    unique_dates        = ('date', lambda x: len(set(x.dropna()))),
    interval_from_start = ('date', lambda x: (x.dropna().min() - date_min).days),
    interval_from_end   = ('date', lambda x: (date_max - x.dropna().max()).days),
    interval_user       = ('date', lambda x: (x.dropna().max() - x.dropna().min()).days),
    sum_visit_Number = ('visitNumber', lambda x: x.dropna().sum()),
    max_visit_num    = ('visitNumber', lambda x: x.dropna().max()),
    # same_continent_user = ('geoNetwork_continent', lambda x: x.dropna().nunique() == 1),
    # n_continents        = ('geoNetwork_continent', f_uninque),
    # same_subcontinent_user = ('geoNetwork_subContinent', lambda x: x.dropna().nunique() == 1),
    # n_subcontinents        = ('geoNetwork_subContinent', f_uninque),
    n_visitStartTime        = ('visitStartTime', lambda x: x.dropna().count()),
    interval_visitStartTime = ('visitStartTime', lambda x: x.dropna().max() - x.dropna().min()),
    # n_device_deviceCategory          = ('device_deviceCategory', f_uninque),
    most_freq_device_isMobile        = ('device_isMobile', lambda x: x.dropna().value_counts().get(False, 0)==0),
    most_freq_device_deviceCategory  = ('device_deviceCategory',    f_most_freq),
    most_freq_device_operatingSystem = ('device_operatingSystem',   f_most_freq),
    most_freq_networkDomain          = ('geoNetwork_networkDomain', f_most_freq),
    most_freq_channelGrouping        = ('channelGrouping',          f_most_freq),
    most_freq_trafficSource_medium   = ('trafficSource_medium',     f_most_freq),
    most_freq_trafficSource_source   = ('trafficSource_source',     f_most_freq),
    most_freq_trafficSource_keyword  = ('trafficSource_keyword',    f_most_freq),
    sum_totals_pageviews    = ('totals_pageviews', lambda x: x.dropna().sum()),
    min_totals_pageviews    = ('totals_pageviews', lambda x: x.dropna().min()),
    max_totals_pageviews    = ('totals_pageviews', lambda x: x.dropna().max()),
    mean_totals_pageviews   = ('totals_pageviews', lambda x: x.dropna().mean()),
    std_totals_pageviews    = ('totals_pageviews', lambda x: x.dropna().std()),
    median_totals_pageviews = ('totals_pageviews', lambda x: x.dropna().median()),
    sum_hits    = ('totals_hits', lambda x: x.dropna().sum()), 
    min_hits    = ('totals_hits', lambda x: x.dropna().min()), 
    max_hits    = ('totals_hits', lambda x: x.dropna().max()), 
    mean_hits   = ('totals_hits', lambda x: x.dropna().mean()),
    std_hits    = ('totals_hits', lambda x: x.dropna().std()),
    median_hits = ('totals_hits', lambda x: x.dropna().median()),
  ).fillna(0)
  df[cat_features] = df[cat_features].astype('category')
  if is_train:
    df['target'] = target
    # df['is_returned'] = is_returned
    df['clf_target'] = (df.target>0).astype(int)
  return df

def split_features_pipeline(train, splits=4, gap=10):
  '''
  разбивает train на непересекающиеся куски и на каждом генерит фичи, после чего конкат
  '''
  delta = (train.date.max()-train.date.min())/splits
  train_list = [train[train.date.between(train.date.min()+i*delta, train.date.min()+(i+1)*delta)] for i in range(splits)]
  return pd.concat([features_pipeline(df_full=i, gap=gap) for i in tqdm(train_list)], axis=0).reset_index()

class ColumnTransformer:
  '''
  уменьшает количество категориальных признаков до 6 самых популярных,
  делает transform на новых данных
  '''
  def __init__(self, max_cat_unique=6):
    self.max_cat_unique = max_cat_unique
    self.map = {}
  def fit(self, df):
    for i in cat_features:
      if df[i].nunique() > self.max_cat_unique:
        top_10 = df[i].value_counts().index[:self.max_cat_unique].astype('category')
        self.map[i] = top_10
    return self
  def transform(self, df):
    for i in cat_features:
      if i in self.map and i in df.columns:
        df.loc[:,i] = df[i].apply(lambda x: x if x in self.map[i] else 'other')
    return df
  def fit_transform(self, df):
    self.fit(df)
    return self.transform(df)

# ===========================================================================
# 2. Training
# ===========================================================================

clf_params = dict(
  objective = 'binary',
  max_bin = 256,
  bagging_fraction = 0.7,
  min_data_in_leaf = 6,
  bagging_freq = 1,
  random_state = 42,
  metric='AUC',
  verbosity=-1,
  early_stopping_rounds=10
)

def msleLoss(y_raw, tr_data=None, y_true=None, is_custom_objective=False):
  if y_true is None: y_true = tr_data.get_label()
  res = y_true - y_raw
  cond_less = res < 0
  res = np.square(res)
  res[cond_less] *= 1.2
  return 'msle', np.mean(res), False

def custom_log_loss_grad_hess(y_raw, tr_data=None, y_true=None, unsure_bounds=(2, 13)):
  if y_true is None: y_true = tr_data.get_label()
  unsure_zone = (unsure_bounds[0] < y_raw) & (y_raw < unsure_bounds[1])
  grad = y_raw - y_true
  grad[unsure_zone] = (2*(y_true[unsure_zone] <= np.mean(unsure_zone))-1)*(unsure_bounds[0] + unsure_bounds[1]) / 2
  hess_max = 3
  hess = y_raw.copy()
  hess[unsure_zone]  = 1 + 2 * (hess_max-1) * np.min([y_raw[unsure_zone]-unsure_bounds[0], unsure_bounds[1]-y_raw[unsure_zone]], axis=0) / (unsure_bounds[1]-unsure_bounds[0])
  hess[~unsure_zone] = 1 
  return grad, hess

r_params = dict(
  objective = custom_log_loss_grad_hess,
  max_bin = 256,
  min_data_in_leaf = 6,
  random_state = 42,
  verbosity=-1,
)

# ===========================================================================
# pipelines
# ===========================================================================

def train_pipeline(train_concat_path='data/train_concat.csv', CT_path='data/CT.pkl'):
  '''
  делает все подряд, выводит модели и данные
  '''
  # 1. Preprocessing
  if not os.path.exists(train_concat_path) or not os.path.exists(CT_path):
    print('Preprocessing...')
    train = proper_types(pd.read_parquet('data/train.parquet'))
    train_concat = split_features_pipeline(train, splits=4, gap=10).query(f'~({zero_query})')
    CT = ColumnTransformer(max_cat_unique=5).fit(train_concat)
    train_concat = CT.transform(train_concat)
    train_concat.to_csv(train_concat_path)
    pickle.dump(CT, open(CT_path, 'wb'))
  else:
    train_concat = pd.read_csv(train_concat_path, index_col=0)
    CT = pickle.load(open(CT_path, 'rb'))

  # 2. Augmentation and Resampling
  clf_train, clf_target = ADASYN(random_state=42, sampling_strategy=0.02).fit_resample(\
    train_concat.drop(not_features+cat_features, axis=1), train_concat['clf_target']
    )
  clf_train, clf_target = TomekLinks(sampling_strategy='majority').fit_resample(clf_train, clf_target)
  clf_train, clf_target = ClusterCentroids(\
    sampling_strategy=0.3, estimator=MiniBatchKMeans(n_clusters=7, random_state=42), random_state=42
    ).fit_resample(clf_train, clf_target)
  
  # 3. Classification
  X_train_clf, X_test_clf, y_train_clf, y_test_clf = train_test_split(clf_train, clf_target, test_size=0.4, random_state=42)
  tr_data  = lgb.Dataset(X_train_clf, y_train_clf, free_raw_data=False)
  val_data = lgb.Dataset(X_test_clf, y_test_clf, free_raw_data=False)
  clf_kwargs = dict(
    train_set  = tr_data,
    valid_sets = [val_data],
    valid_names = ['val'],
    num_boost_round = 250,
    callbacks = [lgb.log_evaluation(period=50)]
  )
  clf_model = lgb.train(params=clf_params, **clf_kwargs)

  # 4. Regression
  train_concat[cat_features] = train_concat[cat_features].astype('category')
  X_train_r, X_test_r, y_train_r, y_test_r = train_test_split(train_concat.drop(not_features, axis=1), train_concat['target'], test_size=0.4, random_state=42)
  tr_data  = lgb.Dataset(X_train_r, y_train_r, categorical_feature=cat_features, free_raw_data=False)
  val_data = lgb.Dataset(X_test_r, y_test_r, categorical_feature=cat_features, free_raw_data=False)
  r_kwargs = dict(
    train_set  = tr_data,
    valid_sets = [val_data],
    valid_names = ['val'],
    num_boost_round = 250,
    callbacks = [lgb.log_evaluation(period=50)]
  )
  r_model = lgb.train(r_params, feval=msleLoss, **r_kwargs)
  return CT, clf_model, r_model, (X_train_clf, X_test_clf, y_train_clf, y_test_clf), (X_train_r, X_test_r, y_train_r, y_test_r)

def test_pipeline(test_concat_path, CT, clf_model, r_model, output_path='submission.csv'):
  '''
  принимает модели, делает предикт перемножая вероятность классификации на результат регрессии
  '''
  # 1.1 Preprocessing
  if not os.path.exists(test_concat_path):
    print('Preprocessing...')
    test = proper_types(pd.read_parquet('data/test.parquet'))
    test = features_pipeline(test, is_train=False)
    test.to_csv(test_concat_path)
  else:
    test = pd.read_csv(test_concat_path)
  
  test['target'] = 0.
  test_to_predict = test.query(f'~({zero_query})')
  test_to_predict = CT.transform(test_to_predict)
  test_to_predict[cat_features] = test_to_predict[cat_features].astype('category')

  # # 1.2 Predictions
  clf_preds = clf_model.predict(test_to_predict.drop(not_features+cat_features, axis=1, errors='ignore'))
  r_preds   =   r_model.predict(test_to_predict.drop(not_features, axis=1, errors='ignore'))
  r_preds[r_preds<0] = 0
  res_preds = clf_preds * (np.exp(r_preds)-1)
  test.loc[test_to_predict.index, 'target'] = res_preds
  test.reset_index()[['fullVisitorId', 'target']].to_csv(output_path, index=False)


# ===========================================================================
# 3. Drawings
# ===========================================================================

def plot_grad_hess(fobj, y_trues=np.array([0,12,25])):
  '''
  рисует градиент и гессиан для каждого y_true
  '''
  y_raws = np.linspace(0,25,100)
  fig, ax = plt.subplots(ncols=2, figsize=(15,5))
  colors = plt.cm.tab10(range(len(y_trues)))
  for i, y_true in enumerate(y_trues):
    grad, hess = fobj(y_raws, y_true=y_true*np.ones_like(y_raws))
    random_noize_grad = np.random.normal(0, max(abs(grad))/300, len(grad))
    random_noize_hess = np.random.normal(0, max(abs(hess))/50, len(grad))
    ax[0].scatter(y_raws+random_noize_grad, grad, color=colors[i], alpha=0.7, s=10, label=f'y_true={y_true}')
    ax[1].scatter(y_raws+random_noize_hess, hess, color=colors[i], alpha=0.7, s=10, label=f'y_true={y_true}')
  m1, M1 = ax[0].get_ylim()
  m2, M2 = ax[1].get_ylim()
  for i, y_true in enumerate(y_trues):
    ax[0].vlines(y_true, m1, M1, linestyles='dashed', color=colors[i])
    ax[1].vlines(y_true, m2, M2, linestyles='dashed', color=colors[i])
  ax[0].hlines(0, *ax[0].get_xlim(), linestyles='dashed', color='grey')
  ax[0].legend()
  ax[1].legend()
  ax[0].set_xlabel('y_raw')
  ax[1].set_xlabel('y_raw')
  ax[0].set_ylabel('grad')
  ax[1].set_ylabel('hess')