import gc
import lightgbm as lgb  # type: ignore
import numpy as np  # type: ignore
import pandas as pd  # type: ignore
import polars as pl  # type: ignore
import warnings

from catboost import CatBoostClassifier, Pool  # type: ignore
from glob import glob
from IPython.display import display  # type: ignore
from pathlib import Path
from sklearn.base import BaseEstimator, ClassifierMixin  # type: ignore
from sklearn.metrics import roc_auc_score  # type: ignore
from sklearn.model_selection import StratifiedGroupKFold  # type: ignore
from typing import Any

warnings.filterwarnings("ignore")

ROOT = Path("/kaggle/input/home-credit-credit-risk-model-stability")
TRAIN_DIR = ROOT / "parquet_files" / "train"
TEST_DIR = ROOT / "parquet_files" / "test"


# ============================================================================================================================================
# Базовые функции для уменьшения размера файлов
# ============================================================================================================================================

class Utility:
    @staticmethod
    def get_feat_defs(ending_with: str) -> None:
        """Retrieves feature definitions from a CSV file based on the specified ending."""
        feat_defs: pl.DataFrame = pl.read_csv(ROOT / "feature_definitions.csv")
        filtered_feats: pl.DataFrame = feat_defs.filter(
            pl.col("Variable").apply(lambda var: var.endswith(ending_with))
        )
        with pl.Config(fmt_str_lengths=200, tbl_rows=-1): print(filtered_feats)
        filtered_feats = None
        feat_defs = None

    @staticmethod
    def find_index(lst: list[Any], item: Any) -> int | None:
        """Finds the index of an item in a list."""
        try: return lst.index(item)
        except ValueError: return None

    @staticmethod
    def dtype_to_str(dtype: pl.DataType) -> str:
        """Converts Polars data type to string representation."""
        dtype_map = {pl.Decimal: "Decimal",pl.Float32: "Float32",pl.Float64: "Float64",pl.UInt8: "UInt8",pl.UInt16: "UInt16",pl.UInt32: "UInt32",pl.UInt64: "UInt64",pl.Int8: "Int8",pl.Int16: "Int16",pl.Int32: "Int32",pl.Int64: "Int64",pl.Date: "Date",pl.Datetime: "Datetime",pl.Duration: "Duration",pl.Time: "Time",pl.Array: "Array",pl.List: "List",pl.Struct: "Struct",pl.String: "String",pl.Categorical: "Categorical",pl.Enum: "Enum",pl.Utf8: "Utf8",pl.Binary: "Binary",pl.Boolean: "Boolean",pl.Null: "Null",pl.Object: "Object",pl.Unknown: "Unknown",}
        return dtype_map.get(dtype)

    @staticmethod
    def find_feat_occur(regex_path: str, ending_with: str) -> pl.DataFrame:
        """Finds occurrences of features ending with a specific string in Parquet files."""
        feat_defs = pl.read_csv(ROOT / "feature_definitions.csv").filter(
            pl.col("Variable").apply(lambda var: var.endswith(ending_with))
        )
        feat_defs.sort(by=["Variable"])
        feats = feat_defs["Variable"].to_list()
        feats.sort()
        occurrences = [[set(), set()] for _ in range(feat_defs.height)]
        for path in glob(str(regex_path)):
            df_schema = pl.read_parquet_schema(path)
            for feat, dtype in df_schema.items():
                index = Utility.find_index(feats, feat)
                if index != None:
                    occurrences[index][0].add(Utility.dtype_to_str(dtype))
                    occurrences[index][1].add(Path(path).stem)
        data_types = [None] * feat_defs.height
        file_locs = [None] * feat_defs.height
        for i, feat in enumerate(feats):
            data_types[i] = list(occurrences[i][0])
            file_locs[i] = list(occurrences[i][1])
        feat_defs = feat_defs.with_columns(pl.Series(data_types).alias("Data_Type(s)"))
        feat_defs = feat_defs.with_columns(pl.Series(file_locs).alias("File_Loc(s)"))
        return feat_defs

    def reduce_memory_usage(df: pl.DataFrame, name) -> pl.DataFrame:
        """Reduces memory usage of a DataFrame by converting column types."""
        print(f"Memory usage of dataframe \"{name}\" is {round(df.estimated_size('mb'), 4)} MB.")
        int_types = [pl.Int8,pl.Int16,pl.Int32,pl.Int64,pl.UInt8,pl.UInt16,pl.UInt32,pl.UInt64]
        float_types = [pl.Float32, pl.Float64]
        for col in df.columns:
            col_type = df[col].dtype
            if col_type in int_types + float_types:
                c_min = df[col].min()
                c_max = df[col].max()
                if c_min is not None and c_max is not None:
                    if col_type in int_types:
                        if c_min >= 0:
                            if (c_min >= np.iinfo(np.uint8).min and c_max <= np.iinfo(np.uint8).max): df = df.with_columns(df[col].cast(pl.UInt8))
                            elif (c_min >= np.iinfo(np.uint16).min and c_max <= np.iinfo(np.uint16).max): df = df.with_columns(df[col].cast(pl.UInt16))
                            elif (c_min >= np.iinfo(np.uint32).min and c_max <= np.iinfo(np.uint32).max): df = df.with_columns(df[col].cast(pl.UInt32))
                            elif (c_min >= np.iinfo(np.uint64).min and c_max <= np.iinfo(np.uint64).max): df = df.with_columns(df[col].cast(pl.UInt64))
                        else:
                            if (c_min >= np.iinfo(np.int8).min and c_max <= np.iinfo(np.int8).max): df = df.with_columns(df[col].cast(pl.Int8))
                            elif (c_min >= np.iinfo(np.int16).min and c_max <= np.iinfo(np.int16).max): df = df.with_columns(df[col].cast(pl.Int16))
                            elif (c_min >= np.iinfo(np.int32).min and c_max <= np.iinfo(np.int32).max): df = df.with_columns(df[col].cast(pl.Int32))
                            elif (c_min >= np.iinfo(np.int64).min and c_max <= np.iinfo(np.int64).max): df = df.with_columns(df[col].cast(pl.Int64))
                    elif col_type in float_types: 
                        if (c_min > np.finfo(np.float32).min and c_max < np.finfo(np.float32).max):
                            df = df.with_columns(df[col].cast(pl.Float32))
        print(f"Memory usage of dataframe \"{name}\" became {round(df.estimated_size('mb'), 4)} MB.")
        return df

    def to_pandas(df: pl.DataFrame, cat_cols: list[str] = None) -> (pd.DataFrame, list[str]):  # type: ignore
        """Converts a Polars DataFrame to a Pandas DataFrame."""
        df = df.to_pandas()
        if cat_cols is None: cat_cols = list(df.select_dtypes("object").columns)
        df[cat_cols] = df[cat_cols].astype("str")
        return df, cat_cols


# ============================================================================================================================================
# Аггрегация признаков для depthN
# ============================================================================================================================================

class Aggregator:
    @staticmethod
    def min_expr(df: pl.LazyFrame) -> list[pl.Series]:
        cols = [col for col in df.columns if (col[-1] in ("P", "M", "A", "D", "T", "L")) and ("num_group" not in col)]
        expr = [pl.col(col).min().alias(f"min_{col}") for col in cols]
        return expr
    
    @staticmethod
    def max_expr(df: pl.LazyFrame) -> list[pl.Series]:
        cols = [col for col in df.columns if (col[-1] in ("P", "M", "A", "D", "T", "L")) or ("num_group" in col)]
        expr = [pl.col(col).max().alias(f"max_{col}") for col in cols]
        return expr

    @staticmethod
    def mean_expr(df: pl.LazyFrame) -> list[pl.Series]:
        cols = [col for col in df.columns if col.endswith(("P", "A", "D"))]
        expr = [pl.col(col).mean().alias(f"mean_{col}") for col in cols]
        return expr

    @staticmethod
    def var_expr(df: pl.LazyFrame) -> list[pl.Series]:
        cols = [col for col in df.columns if col.endswith(("P", "A", "D"))]
        expr = [pl.col(col).var().alias(f"var_{col}") for col in cols]
        return expr

    @staticmethod
    def mode_expr(df: pl.LazyFrame) -> list[pl.Series]:
        cols = [col for col in df.columns if col.endswith("M")]
        expr = [pl.col(col).drop_nulls().mode().first().alias(f"mode_{col}") for col in cols]
        return expr
    
    @staticmethod
    def person1_min_expr(df: pl.LazyFrame) -> list[pl.Series]:
        cols = [col for col in df.columns if ("num_group" not in col)]
        expr = [pl.col(col).filter(pl.col("num_group1") == 0).min().alias(f"person1_min_{col}") for col in cols]
        return expr
    
    @staticmethod
    def person1_max_expr(df: pl.LazyFrame) -> list[pl.Series]:
        cols = [col for col in df.columns if ("num_group" not in col)]
        expr = [pl.col(col).filter(pl.col("num_group1") == 0).max().alias(f"person1_max_{col}") for col in cols]
        return expr
    
    @staticmethod
    def person1_mean_expr(df: pl.LazyFrame) -> list[pl.Series]:
        cols = [col for col in df.columns if ("num_group" not in col)]
        expr = [pl.col(col).filter(pl.col("num_group1") == 0).mean().alias(f"person1_mean_{col}") for col in cols]
        return expr
    
    @staticmethod
    def person2_min_expr(df: pl.LazyFrame) -> list[pl.Series]:
        cols = [col for col in df.columns if ("num_group" not in col)]
        expr = [pl.col(col).filter(pl.col("num_group2") == 0).min().alias(f"person2_min_{col}") for col in cols]
        return expr
    
    @staticmethod
    def person2_max_expr(df: pl.LazyFrame) -> list[pl.Series]:
        cols = [col for col in df.columns if ("num_group" not in col)]
        expr = [pl.col(col).filter(pl.col("num_group2") == 0).max().alias(f"person2_max_{col}") for col in cols]
        return expr
    
    @staticmethod
    def person2_mean_expr(df: pl.LazyFrame) -> list[pl.Series]:
        cols = [col for col in df.columns if ("num_group" not in col)]
        expr = [pl.col(col).filter(pl.col("num_group2") == 0).mean().alias(f"person2_mean_{col}") for col in cols]
        return expr


# ============================================================================================================================================
# GPT-50, описание фичей удалил)))
# ============================================================================================================================================

def gpt_features_50(df):
    df = df.with_columns([
        (pl.col('amtinstpaidbefduel24m_4187115A') / pl.col('numinstls_657L')).alias('gpt_avg_instalments_paid_before_due_per_instalment'),
        (pl.col('annuity_780A') - pl.col('annuitynextmonth_57A')).alias('gpt_change_in_annuity'),
        (pl.col('applications30d_658L') / pl.col('applicationcnt_361L')).alias('gpt_applications_ratio_last_30_days'),
        (pl.col('applicationscnt_629L') / pl.col('applicationscnt_464L')).alias('gpt_applications_with_same_employer_7d_vs_30d'),
        (pl.col('applicationscnt_867L') / pl.col('applicationscnt_1086L')).alias('gpt_mobile_vs_phone_applications'),
        (pl.col('avgdbddpdlast24m_3658932P') - pl.col('avgdbddpdlast3m_4187120P')).alias('gpt_avg_days_past_due_24m_vs_3m'),
        (pl.col('avgdpdtolclosure24_3658938P') / pl.col('avgdbddpdlast24m_3658932P')).alias('gpt_tolerant_vs_non_tolerant_dpd_24m'),
        (pl.col('avginstallast24m_3658937A') / pl.col('avglnamtstart24m_4525187A')).alias('gpt_avg_installment_vs_loan_amount_24m'),
        (pl.col('avgmaxdpdlast9m_3716943P') / pl.col('maxdpdlast9m_1059P')).alias('gpt_avg_vs_max_dpd_9m'),
        (pl.col('avgoutstandbalancel6m_4187114A') / pl.col('totaldebt_9A')).alias('gpt_avg_outstanding_balance_vs_total_debt'),
        (pl.col('avgpmtlast12m_4525200A') / pl.col('totalsettled_863A')).alias('gpt_avg_payments_vs_total_settled_12m'),
        (pl.col('clientscnt12m_3712952L') / pl.col('clientscnt3m_3712950L')).alias('gpt_clients_same_mobile_12m_vs_3m'),
        (pl.col('cntincpaycont9m_3716944L') / pl.col('pmtnum_254L')).alias('gpt_incoming_payments_vs_total_payments'),
        (pl.col('commnoinclast6m_3546845L') / pl.col('numinstls_657L')).alias('gpt_low_income_communications_vs_instalments'),
        (pl.col('contractssum_5085716L') / pl.col('sumoutstandtotal_3546847A')).alias('gpt_contracts_sum_vs_outstanding_total'),
        (pl.col('credamount_770A') / pl.col('maininc_215A')).alias('gpt_loan_amount_vs_primary_income'),
        (pl.col('currdebt_22A') / pl.col('totaldebt_9A')).alias('gpt_current_debt_vs_total_debt'),
        (pl.col('datefirstoffer_1144D').cast(pl.Date).dt.year() - pl.col('birthdate_574D').cast(pl.Date).dt.year()).alias('gpt_years_since_birth_to_first_offer'),
        (pl.col('days120_123L') / pl.col('days360_512L')).alias('gpt_credit_queries_120d_vs_360d'),
        (pl.col('deferredmnthsnum_166L') / pl.col('numinstls_657L')).alias('gpt_deferred_months_vs_instalments'),
        (pl.col('disbursedcredamount_1113A') / pl.col('credamount_770A')).alias('gpt_disbursed_vs_loan_amount'),
        (pl.col('downpmt_116A') / pl.col('credamount_770A')).alias('gpt_downpayment_vs_loan_amount'),
        (pl.col('eir_270L') / pl.col('interestrate_311L')).alias('gpt_effective_vs_contract_interest_rate'),
        (pl.col('firstdatedue_489D').cast(pl.Date).dt.year() - pl.col('birthdate_574D').cast(pl.Date).dt.year()).alias('gpt_years_since_birth_to_first_due_date'),
        (pl.col('for3years_128L') / pl.col('applicationcnt_361L')).alias('gpt_rejections_ratio_3_years'),
        (pl.col('lastactivateddate_801D').cast(pl.Date).dt.year() - pl.col('birthdate_574D').cast(pl.Date).dt.year()).alias('gpt_years_since_birth_to_last_activation'),
        (pl.col('lastapprcredamount_781A') / pl.col('credamount_770A')).alias('gpt_last_approved_vs_current_loan_amount'),
        (pl.col('lastdelinqdate_224D').cast(pl.Date).dt.year() - pl.col('birthdate_574D').cast(pl.Date).dt.year()).alias('gpt_years_since_birth_to_last_delinquency'),
        (pl.col('lastotherinc_902A') / pl.col('maininc_215A')).alias('gpt_last_other_income_vs_primary_income'),
        (pl.col('lastrejectcredamount_222A') / pl.col('credamount_770A')).alias('gpt_last_rejected_vs_current_loan_amount'),
        (pl.col('lastrepayingdate_696D').cast(pl.Date).dt.year() - pl.col('birthdate_574D').cast(pl.Date).dt.year()).alias('gpt_years_since_birth_to_last_repayment'),
        (pl.col('maxannuity_4075009A') / pl.col('annuity_780A')).alias('gpt_max_annuity_vs_current_annuity'),
        (pl.col('maxdebt4_972A') / pl.col('totaldebt_9A')).alias('gpt_max_debt_4m_vs_total_debt'),
        (pl.col('maxdpdlast12m_727P') / pl.col('avgmaxdpdlast9m_3716943P')).alias('gpt_max_dpd_12m_vs_avg_9m'),
        (pl.col('maxdpdtolerance_374P') / pl.col('avgdbddpdlast24m_3658932P')).alias('gpt_max_vs_avg_dpd_tolerance_24m'),
        (pl.col('mindbddpdlast24m_3658935P') / pl.col('avgdbddpdlast24m_3658932P')).alias('gpt_min_vs_avg_dpd_24m'),
        (pl.col('mobilephncnt_593L') / pl.col('applicationcnt_361L')).alias('gpt_mobile_phone_count_ratio'),
        (pl.col('numactivecreds_622L') / pl.col('numactivecredschannel_414L')).alias('gpt_active_credits_channel_ratio'),
        (pl.col('numinstlswithdpd10_728L') / pl.col('numinstls_657L')).alias('gpt_instalments_with_dpd10_ratio'),
        (pl.col('numinstlswithdpd5_4187116L') / pl.col('numinstls_657L')).alias('gpt_instalments_with_dpd5_ratio'),
        (pl.col('numinstpaidearly_338L') / pl.col('numinstls_657L')).alias('gpt_instalments_paid_early_ratio'),
        (pl.col('numinsttopaygr_769L') / pl.col('numinstls_657L')).alias('gpt_unpaid_instalments_ratio'),
        (pl.col('numrejects9m_859L') / pl.col('applicationcnt_361L')).alias('gpt_rejections_9m_ratio'),
        (pl.col('pctinstlsallpaidearl3d_427L') / pl.col('pctinstlsallpaidlate1d_3546856L')).alias('gpt_pct_early_vs_late_instalments_3d'),
        (pl.col('pctinstlsallpaidlate6d_3546844L') / pl.col('pctinstlsallpaidlate1d_3546856L')).alias('gpt_pct_late6d_vs_late1d_instalments'),
        (pl.col('totaldebt_9A') / pl.col('credamount_770A')).alias('gpt_total_debt_vs_loan_amount')
    ])
    return df
    


# ============================================================================================================================================
# Функции для загрузки и аггрегации данных
# ============================================================================================================================================

class SchemaGen:
    @staticmethod
    def change_dtypes(df: pl.LazyFrame) -> pl.LazyFrame:
        """Changes the data types of columns in the DataFrame."""
        for col in df.columns:
            if col == "case_id":
                df = df.with_columns(pl.col(col).cast(pl.UInt32).alias(col))
            elif col in ["WEEK_NUM", "num_group1", "num_group2"]:
                df = df.with_columns(pl.col(col).cast(pl.UInt16).alias(col))
            elif col == "date_decision" or col[-1] == "D":
                df = df.with_columns(pl.col(col).cast(pl.Date).alias(col))
            elif col[-1] in ["P", "A"]:
                df = df.with_columns(pl.col(col).cast(pl.Float64).alias(col))
            elif col[-1] in ("M",):
                df = df.with_columns(pl.col(col).cast(pl.String))
        return df
    
    @staticmethod
    def scan_files(glob_path: str, depth: int = None):
        chunks = []
        for path in glob(str(glob_path)):
            df = pl.read_parquet(path, low_memory=True, rechunk=True)
            df = df.pipe(SchemaGen.change_dtypes)
            if depth in [1, 2]:
                person2_exprs = Aggregator.person2_min_expr(df) + Aggregator.person2_max_expr(df) + Aggregator.person2_mean_expr(df)
                df = df.groupby("case_id").agg(
                    Aggregator.min_expr(df) + 
                    Aggregator.max_expr(df) + 
                    Aggregator.mean_expr(df) + 
                    Aggregator.var_expr(df) + 
                    Aggregator.mode_expr(df) +
                    Aggregator.person1_min_expr(df) +
                    Aggregator.person1_max_expr(df) +
                    Aggregator.person1_mean_expr(df) +
                    person2_exprs if depth == 2 else []
                )
            chunks.append(df)
        df = pl.concat(chunks, how="vertical_relaxed")
        del chunks
        gc.collect()
        df = df.unique(subset=["case_id"])
        return df

    @staticmethod
    def join_dataframes(df_base: pl.LazyFrame,depth_0: list[pl.LazyFrame],depth_1: list[pl.LazyFrame],depth_2: list[pl.LazyFrame]) -> pl.DataFrame:
        for i, df in enumerate(depth_0 + depth_1 + depth_2):
            df_base = df_base.join(df, how="left", on="case_id", suffix=f"_{i}")
        df_base = gpt_features_50(df_base)
        return df_base

def filter_cols(df: pl.DataFrame) -> pl.DataFrame:
    """Filters columns in the DataFrame based on null percentage and unique values for string columns."""
    for col in df.columns:
        if col not in ["case_id", "year", "month", "week_num", "target"]:
            null_pct = df[col].is_null().mean()
            n_unique = df[col].n_unique()
            if null_pct > 0.95 or n_unique == 1:
                df = df.drop(col)
    for col in df.columns:
        if (col not in ["case_id", "year", "month", "week_num", "target"]) & (df[col].dtype == pl.String):
            freq = df[col].n_unique()
            if (freq > 200) | (freq == 1):
                df = df.drop(col)
    return df

def handle_dates(df: pl.DataFrame) -> pl.DataFrame:
    """Handles date columns in the DataFrame."""
    for col in df.columns:
        if col.endswith("D"):
            df = df.with_columns((pl.col("date_decision")-pl.col(col)).dt.total_days().cast(pl.Int32).alias(col))    
    return df.drop("date_decision").rename({"MONTH": "month","WEEK_NUM": "week_num"})


# ============================================================================================================================================
# pipeline
# ============================================================================================================================================


def get_df(train=True, write=False):
    train_test = 'train' if train else 'test'
    root_dir = TRAIN_DIR if train else TEST_DIR
    data_store = {
        "df_base": SchemaGen.scan_files(root_dir / f"{train_test}_base.parquet"),
        "depth_0": [
            SchemaGen.scan_files(root_dir / f"{train_test}_static_cb_0.parquet"),
            SchemaGen.scan_files(root_dir / f"{train_test}_static_0_*.parquet"),
        ],
        "depth_1": [
            SchemaGen.scan_files(root_dir / f"{train_test}_applprev_1_*.parquet", 1),
            SchemaGen.scan_files(root_dir / f"{train_test}_tax_registry_a_1.parquet", 1),
            SchemaGen.scan_files(root_dir / f"{train_test}_tax_registry_b_1.parquet", 1),
            SchemaGen.scan_files(root_dir / f"{train_test}_tax_registry_c_1.parquet", 1),
            SchemaGen.scan_files(root_dir / f"{train_test}_credit_bureau_a_1_*.parquet", 1),
            SchemaGen.scan_files(root_dir / f"{train_test}_credit_bureau_b_1.parquet", 1),
            SchemaGen.scan_files(root_dir / f"{train_test}_other_1.parquet", 1),
            SchemaGen.scan_files(root_dir / f"{train_test}_person_1.parquet", 1),
            SchemaGen.scan_files(root_dir / f"{train_test}_deposit_1.parquet", 1),
            SchemaGen.scan_files(root_dir / f"{train_test}_debitcard_1.parquet", 1),
        ],
        "depth_2": [
            SchemaGen.scan_files(root_dir / f"{train_test}_credit_bureau_a_2_*.parquet", 2),
            SchemaGen.scan_files(root_dir / f"{train_test}_credit_bureau_b_2.parquet", 2),
        ],
    }

    if train:
        df = (
            SchemaGen.join_dataframes(**data_store)
            .pipe(filter_cols)
            .pipe(handle_dates)
            .pipe(Utility.reduce_memory_usage, "df")
        )
    else:
        df = (
            SchemaGen.join_dataframes(**data_store)
            .pipe(handle_dates)
            .pipe(Utility.reduce_memory_usage, "df")
        )


    del data_store
    gc.collect()

    print(f"{train_test} data shape: {df.shape}")
    display(df.head(10))

    if write: df_train.write_parquet(f"{train_test}_final.parquet", compression="lz4")
    return df



# ============================================================================================================================================
# other: TargetEncoder
# ============================================================================================================================================


class TargetEncoder:
  def __init__(self, cat_cols=None, min_samples_leaf=1, smoothing=1,noise_level=0):
    self.min_samples_leaf = min_samples_leaf
    self.smoothing = smoothing
    self.noise_level = noise_level
    self.cat_cols = cat_cols
    self.priors = {}
    self.avgs = {}
    self.names = {}
  
  def fit(self, X, y):
    X_new = X.copy()
    target = y
    for cat_col in self.cat_cols:
      trn_series = X_new[cat_col]
      temp = pd.concat([trn_series, target], axis=1)
      averages = temp.groupby(by=trn_series.name)[target.name].agg(["mean", "count"])
      smoothing = 1 / (1 + np.exp(-(averages["count"] - self.min_samples_leaf) / self.smoothing))
      prior = target.mean()
      averages[target.name] = prior * (1 - smoothing) + averages["mean"] * smoothing
      averages.drop(["mean", "count"], axis=1, inplace=True)
      self.priors[cat_col] = prior
      self.avgs[cat_col] = averages.reset_index().rename(columns={'index': target.name, target.name: 'average'})
      self.names[cat_col] = trn_series.name
    return self
  
  def transform(self, X, y=None):
    X_new = X.copy()
    for cat_col in self.cat_cols:
      tst_series = X_new[cat_col]
      averages = self.avgs[cat_col]
      prior = self.priors[cat_col]
      ft_tst_series = pd.merge(
        tst_series.to_frame(tst_series.name),
        averages,
        on=tst_series.name,
        how='left')['average'].rename(self.names[cat_col] + '_mean').fillna(prior)
      ft_tst_series.index = tst_series.index
      X_new[cat_col] = add_noise(ft_tst_series, self.noise_level)
    return X_new
  
  def fit_transform(self, X, y):
    return self.fit(X, y).transform(X)